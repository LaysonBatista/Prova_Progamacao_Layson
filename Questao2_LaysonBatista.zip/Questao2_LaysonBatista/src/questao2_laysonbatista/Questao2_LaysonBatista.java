/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao2_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao2_LaysonBatista {

    private static Component rootPane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DataInputStream dado = new DataInputStream(System.in);
        Scanner scanner = new Scanner(System.in);
        
        int parar = 0;
        int escolha = 0;
        
        
        double expresso = 0.75;
        double cappucino = 1.0;
        double comLeite = 1.25;
        int quantidadeExpresso = 0;
        int quantidadeCappucino = 0;
        int quantidadeComLeite = 0;
;        
        int totalizaVendas = 0;
        
        System.out.println("<Maquina de cafe>");
        
        String[] opcoesDaMaquina = new String[]{"cafe expresso", "cafe capuccino", "leite com cafe"};
        
        do{
        for(int i = 0; i<opcoesDaMaquina.length; i++){
            System.out.println("[" + i + "]" + opcoesDaMaquina[i]);
        }
        
        System.out.println("Informe qual deseja: ");
        escolha = scanner.nextInt();
          
        System.out.println("Para encerrar digite 9: (para continuar qualquer outro numero) ");
        parar = scanner.nextInt();
        
    } while(parar !=9);
               
        
        
        
        if(escolha > 2){
            System.out.println("opcao nao existe");
        }
        
       else if(escolha == 0){
       ++quantidadeExpresso;    
       System.out.println("Total de cafe expresso vendido: " + quantidadeExpresso);
       } else if(escolha == 1){
           quantidadeCappucino++;
         System.out.println("Total de cafe expresso vendido: " + quantidadeCappucino);  
       } else if(escolha == 2){
           quantidadeComLeite++;
        System.out.println("Total de cafe expresso vendido: " + quantidadeComLeite);  
    }
        
        
        
}
}

