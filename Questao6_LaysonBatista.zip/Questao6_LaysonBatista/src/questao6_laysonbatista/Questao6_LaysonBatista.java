/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao6_laysonbatista;

import java.awt.Component;
import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao6_LaysonBatista {

    private static Component rootPane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        FileWriter arq = new FileWriter("C:\\Users\\aluno\\Desktop\\lutador.txt");
        PrintWriter gravarArq = new PrintWriter(arq);
        
        DataInputStream dado = new DataInputStream(System.in);
        String s = "";
        int nome = 0;
        int peso = 0;
        
        s = JOptionPane.showInputDialog(null,"Informe o nome do lutador: ");
        nome = Integer.parseInt(s);
        
        s = JOptionPane.showInputDialog(null,"Informe o peso do lutador: ");
        peso = Integer.parseInt(s);
        
        if(peso < 65){
            JOptionPane.showMessageDialog(rootPane, "Pena");
        } else{
             JOptionPane.showMessageDialog(rootPane, "outras categorias...");
        }
        
        gravarArq.printf("o lutador " + nome + " pesa " + peso + " e pertence a categoria ");
        
        
    }
    
}
