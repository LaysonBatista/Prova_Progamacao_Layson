/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao4_laysonbatista;

import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao4_LaysonBatista {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DataInputStream dado = new DataInputStream(System.in);
        String s = "";
        int soma = 0;
        int quantidade = 0;
        double media = 0.0;
        
        int numero = 0;
        
        do{
        s = JOptionPane.showInputDialog(null,"Informe um numero: ");
        numero = Integer.parseInt(s);
        
    } while(numero != 0);
         
        
    
}
}
