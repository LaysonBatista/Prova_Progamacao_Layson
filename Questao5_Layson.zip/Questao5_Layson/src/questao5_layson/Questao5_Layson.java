/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao5_layson;

import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Questao5_Layson {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        FileWriter arq = new FileWriter("C:\\Users\\aluno\\Desktop\\tabuada.txt");
        PrintWriter gravarArq = new PrintWriter(arq);
        
        Scanner scanner = new Scanner(System.in);
        DataInputStream dado = new DataInputStream(System.in);
        String s = "";
        int numero = 0;
        
        s = JOptionPane.showInputDialog(null,"Informe um numero: ");
        numero = Integer.parseInt(s);
        
        System.out.println("Tabuada do " + numero);
        
       
        
        arq.close();
    }
    
}
